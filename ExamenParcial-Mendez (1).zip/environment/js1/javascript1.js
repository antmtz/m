console.log("Hola mundo!");
window.onload=function(){
    //Se obtiene el icono siguiente
    var KA = document.getElementById("KA");
    //se registra el evento
    KA.addEventListener("click", verKA);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function verSiguiente(){
        var aux= document.getElementById("producto 13")
        var ruta=aux.src;
        if(ruta.includes('img/I1.jpg'))
        aux.src="img/I1.jpg";
        else if(ruta.includes('img/I2.jpg'))
        aux.src="img/I2.jpg";
        else if(ruta.includes('img/I3.jpg'))
        aux.src="img/I3.jpg";
        else if(ruta.includes('img/I4.jpg'))
        aux.src="img/I4.jpg";
         else if(ruta.includes('img/I5.jpg'))
        aux.src="img/I5.jpg";
        
    } 
      //Se obtiene el incono atras
    var vista_ZA = document.getElementById("ZA");
    //Se registra el evento 
    vista_ZA.addEventListener("click", verZA);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verZA(){
        var aux= document.getElementById("producto 13")
        var ruta=aux.src;
        if(ruta.includes('img/I5.jpg'))
        aux.src="img/I5.jpg";
        else if(ruta.includes('img/I4.jpg'))
        aux.src="img/I4.jpg";
        else if(ruta.includes('img/I3.jpg'))
        aux.src="img/I3.jpg";
        else if(ruta.includes('img/I2.jpg'))
        aux.src="img/I2.jpg";
        else if(ruta.includes('img/I1.jpg'))
        aux.src="img/I1.jpg";
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
    {
        var text= document.getElementById("datos");
        text.innerHTML="°Bordado 100% algondón <br> °Corte princesa";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h5 Ocultr Especificaciones
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
        
    }/*--------------------------------------------------------*/