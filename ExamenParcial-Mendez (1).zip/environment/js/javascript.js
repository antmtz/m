
console.log("Hola mundo!");
window.onload=function(){
    //Se obtiene el icono siguiente
    var siguiente = document.getElementById("adelante");
    //se registra el evento
    siguiente.addEventListener("click", verSiguiente);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function verSiguiente(){
        var aux= document.getElementById("producto")
        var ruta=aux.src;
        if(ruta.includes('andrea/blusas2.1.jpg'))
        aux.src="andrea/blusas2.2.jpg";
        else if(ruta.includes('andrea/blusas2.2.jpg'))
        aux.src="andrea/blusas2.3.jpg";
        else if(ruta.includes('andrea/blusas2.3.jpg'))
        aux.src="andrea/blusas2.4.jpg";
        else
        aux.src="andrea/blusas2.1.jpg";
    } 
      //Se obtiene el incono atras
    var vista_atras = document.getElementById("atras");
    //Se registra el evento 
    vista_atras.addEventListener("click", verAtras);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verAtras(){
        var aux= document.getElementById("producto")
        var ruta=aux.src;
        if(ruta.includes('andrea/blusas2.4.jpg'))
        aux.src="andrea/blusas2.3.jpg";
        else if(ruta.includes('andrea/blusas2.3.jpg'))
        aux.src="andrea/blusas2.2.jpg";
        else if(ruta.includes('andrea/blusas2.2.jpg'))
        aux.src="andrea/blusas2.1.jpg";
        else
        aux.src="andrea/blusas2.4.jpg";
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
    {
        var text= document.getElementById("datos");
        text.innerHTML="°Bordado 100% algondón <br> °Corte princesa";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h5 Ocultr Especificaciones
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
        
    }/*--------------------------------------------------------*/
         var acelera = document.getElementById("acelera");
    //se registra el evento
    acelera.addEventListener("click", veracelera);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function veracelera(){
        var aux= document.getElementById("producto1")
        var ruta=aux.src;
        if(ruta.includes('andrea/blusas3.jpg'))
        aux.src="andrea/blusas3.1.jpg";
        else if(ruta.includes('andrea/blusas3.1.jpg'))
        aux.src="andrea/blusas3.2.jpg";
        else if(ruta.includes('andrea/blusas3.2.jpg'))
        aux.src="andrea/blusas3.3.jpg";
        else
        aux.src="andrea/blusas3.jpg";
    } 
      //Se obtiene el incono atras
    var vista_retrocede = document.getElementById("retrocede");
    //Se registra el evento 
    vista_retrocede.addEventListener("click", verretrocede);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verretrocede(){
        var aux= document.getElementById("producto1")
        var ruta=aux.src;
         if(ruta.includes('andrea/blusas3.jpg'))
        aux.src="andrea/blusas3.3.jpg";
        else if(ruta.includes('andrea/blusas3.3.jpg'))
        aux.src="andrea/blusas3.2.jpg";
        else if(ruta.includes('andrea/blusas3.2.jpg'))
        aux.src="andrea/blusas3.1.jpg";
        else
        aux.src="andrea/blusas3.jpg";
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM

/*--------------------------------------------------------*/
         var a = document.getElementById("a");
    //se registra el evento
    a.addEventListener("click", vera);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function vera(){
        var aux= document.getElementById("producto2")
        var ruta=aux.src;
        if(ruta.includes('andrea/blusas4.jpg'))
        aux.src="andrea/blusas4.1.jpg";
        else if(ruta.includes('andrea/blusas4.1.jpg'))
        aux.src="andrea/blusas4.2.jpg";
        else if(ruta.includes('andrea/blusas4.2.jpg'))
        aux.src="andrea/blusas4.3.jpg";
        else
        aux.src="andrea/blusas4.jpg";
    } 
      //Se obtiene el incono atras
    var vista_r = document.getElementById("r");
    //Se registra el evento 
    vista_r.addEventListener("click", verr);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verr(){
        var aux= document.getElementById("producto2")
        var ruta=aux.src;
         if(ruta.includes('andrea/blusas4.jpg'))
        aux.src="andrea/blusas4.3.jpg";
        else if(ruta.includes('andrea/blusas4.3.jpg'))
        aux.src="andrea/blusas4.2.jpg";
        else if(ruta.includes('andrea/blusas4.2.jpg'))
        aux.src="andrea/blusas4.1.jpg";
        else
        aux.src="andrea/blusas4.jpg";
    }
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
    
    //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("rosa").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("azul").addEventListener("click", function(){ cambiarImagen(this); } );
    
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto2");
        switch (objeto.id) {
            case 'rosa':
                aux.src="andrea/blusas4.jpg"
                break;
                case 'azul':
                aux.src="andrea/blusas5.jpg"
                break;
              default:
              aux.src="andrea/blusas4.jpg"
        }
    }
    }
     //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    //---------------------------------------------------
     var p = document.getElementById("p");
    //se registra el evento
    p.addEventListener("click", verp);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function verp(){
        var aux= document.getElementById("producto4")
        var ruta=aux.src;
        if(ruta.includes('andrea/juv.jpg'))
        aux.src="andrea/juv1.jpg";
        else if(ruta.includes('andrea/juv1.jpg'))
        aux.src="andrea/juv2.jpg";
        else
        aux.src="andrea/juv.jpg";
    } 
      //Se obtiene el incono atras
    var vista_c = document.getElementById("c");
    //Se registra el evento 
    vista_c.addEventListener("click", verc);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verc(){
        var aux= document.getElementById("producto4")
        var ruta=aux.src;
         if(ruta.includes('andrea/juv.jpg'))
        aux.src="andrea/juv2.jpg";
        else if(ruta.includes('andrea/juv2.jpg'))
        aux.src="andrea/juv1.jpg";
        else
        aux.src="andrea/juv.jpg";
    }
 //Se obtiene el elemento h5 Ver Especifiaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click", mostrarEspecificaciones)
    
    //Función que crea y añade elementos html al DOM
    function mostrarEspecificaciones(){
        
        var text= document.getElementById("dat");
        text.innerHTML="> Tejido de punto simple 100% algodón <br> > Corte entallado";
        var instrucciones= document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var img_instrucciones= document.createElement("img");
        img_instrucciones.src="img/cuidados.jpg"
        instrucciones.appendChild(img_instrucciones);
    }
    
    //Se obtiene el elemento h5 Ocultar Especificaciones
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click", ocultarEspecificaciones)
    
    //funcion elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
    }    
    
    
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
       {
        var text= document.getElementById("dat");
        text.innerHTML="°100% algondón <br> °Corteentubado";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h6 Ocultr Especificaciones
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
    }
        //----------------------------------------------
    var s = document.getElementById("s");
    //se registra el evento 
    s.addEventListener("click",vers);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic al icono siguiente
    function vers(){
        var aux= document.getElementById("producto5")
        var ruta=aux.src;
        if(ruta.includes('andrea/p1.jpg'))
        aux.src="andrea/p2.jpg";
        else if(ruta.includes('andrea/p2.jpg'))
        aux.src="andrea/p1.jpg";
    }
    //se obtiene el icono de atras
    var vista_d =document.getElementById("d");
    //se registra el evento
    vista_d.addEventListener("click", verd);
    function verd(){
        var aux= document.getElementById("producto5")
        var ruta=aux.src;
        if(ruta.includes('andrea/p1.jpg'))
        aux.src="andrea/p2.jpg";
        else if(ruta.includes('andrea/p2.jpg'))
        aux.src="andrea/p1.jpg";
    }
     {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
    
    document.getElementById("semi").addEventListener("click",function() {cambiarImagen(this)})
     document.getElementById("fuerte").addEventListener("click",function() {cambiarImagen(this)})
      document.getElementById("claro").addEventListener("click",function() {cambiarImagen(this)})
    function cambiarImagen(objeto)
      {
          var aux = document.getElementById("producto5");
        switch (objeto.id) {
            case 'semi':
                aux.src="andrea/p1.jpg"
                break;
                case 'fuerte':
                aux.src="andrea/p3.jpg"
                break;
                case 'claro':
                aux.src="andrea/p4.jpg"
                break;
        }
      }
      }
        {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("verde").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("mostaza").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("rojo").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("blanco").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("negro").addEventListener("click", function(){ cambiarImagen(this); } );
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto6");
        switch (objeto.id) {
            case 'verde':
                aux.src="andrea/j1.jpg"
                break;
                case 'mostaza':
                aux.src="andrea/j2.jpg"
                break;
                case 'rojo':
                aux.src="andrea/j3.jpg"
                break;
                 case 'blanco':
                aux.src="andrea/j4.jpg"
                break;
                 case 'negro':
                aux.src="andrea/j5.jpg"
                break;
        }
    }
        
    }
  /*---------------------------------CAMISAS---------------------------------------*/
         var anty = document.getElementById("anty");
    //se registra el evento
    anty.addEventListener("click", veranty);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function veranty(){
        var aux= document.getElementById("producto3")
        var ruta=aux.src;
        if(ruta.includes('andrea/c.1.jpg'))
        aux.src="andrea/c2.jpg";
        else if(ruta.includes('andrea/c2.jpg'))
        aux.src="andrea/c.1.jpg";
        
    } 
      //Se obtiene el incono atras
    var vista_sat = document.getElementById("sat");
    //Se registra el evento 
    vista_sat.addEventListener("click", versat);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function versat(){
        var aux= document.getElementById("producto3")
        var ruta=aux.src;
        if(ruta.includes('andrea/c.1.jpg'))
        aux.src="andrea/c1.1.jpg";
        else if(ruta.includes('andrea/c1.1.jpg'))
        aux.src="andrea/c.1.jpg";
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
    {
        var text= document.getElementById("spe");
        text.innerHTML="° 100% algondón <br> °manga larga";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h5 Ocultr Especificaciones
     var text= document.getElementById("spea");
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
        
    }
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("clar").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("obs").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("blac").addEventListener("click", function(){ cambiarImagen(this); } );
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto3");
        switch (objeto.id) {
             case 'blac':
                aux.src="andrea/c.1.jpg"
                break;
            case 'clar':
                aux.src="andrea/c.2.jpg"
                break;
                case 'obs':
                aux.src="andrea/c3.jpg"
                break;
                
        }
    }
        
    }
    /*----------------------------------PARTE 2- CAMISA SPORT--------------------------------------*/
     var oma = document.getElementById("oma");
    //se registra el evento
    oma.addEventListener("click", veroma);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function veroma(){
        var aux= document.getElementById("producto7")
        var ruta=aux.src;
       if(ruta.includes('andrea/c.4.jpg'))
        aux.src="andrea/c.4.1.jpg";
        else if(ruta.includes('andrea/c.4.1.jpg'))
        aux.src="andrea/c.4.2.jpg";
         else if(ruta.includes('andrea/c.4.2.jpg'))
        aux.src="andrea/c.4.jpg";
        
    
    } 
      //Se obtiene el incono atras
    var vista_men = document.getElementById("men");
    //Se registra el evento 
    vista_men.addEventListener("click", vermen);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function vermen(){
         var aux= document.getElementById("producto7")
        var ruta=aux.src;
        if(ruta.includes('andrea/c.4.jpg'))
        aux.src="andrea/c.4.2.jpg";
        else if(ruta.includes('andrea/c.4.2.jpg'))
        aux.src="andrea/c.4.1.jpg";
        else if(ruta.includes('andrea/c.4.1.jpg'))
        aux.src="andrea/c.4.jpg";
    
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
    {
        var text= document.getElementById("spe");
        text.innerHTML="° 100% algondón <br> °manga larga";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h5 Ocultr Especificaciones
     var text= document.getElementById("spea");
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
        
    }
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("opa").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("ilu").addEventListener("click", function(){ cambiarImagen(this); } );
    
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto7");
        switch (objeto.id) {
             case 'opa':
                aux.src="andrea/c.4.3.jpg"
                break;
            case 'ilu':
                aux.src="andrea/c.4.jpg"
                break;
             
        }
    }
    }
    /*-----------------------------------------CAMISAS DE COLRES---------------------*/
     {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("5").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("6").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("7").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("8").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("9").addEventListener("click", function(){ cambiarImagen(this); } );
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto8");
        switch (objeto.id) {
            case '5':
                aux.src="andrea/c.5.jpg"
                break;
                case '6':
                aux.src="andrea/c.6.jpg"
                break;
                case '7':
                aux.src="andrea/c.7.jpg"
                break;
                 case '8':
                aux.src="andrea/c.8.jpg"
                break;
                 case '9':
                aux.src="andrea/c.9.jpg"
                break;
        }
    }
        
    }
   /*-----------------------------------PANTALONES HOMBRE-------------*/
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("g").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("v").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("az").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("ca").addEventListener("click", function(){ cambiarImagen(this); } );
    
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto 9");
        switch (objeto.id) {
            case 'g':
                aux.src="andrea/g.jpg"
                break;
                case 'v':
                aux.src="andrea/v.jpg"
                break;
                 case 'az':
                aux.src="andrea/a.jpg"
                break;
                case 'ca':
                aux.src="andrea/c.jpg"
                break;
        }
    }
       
    }
    /*--------------------------------------PANTALON FORMAL-----------------------------------------------*/
          var ANT = document.getElementById("ANT");
    //se registra el evento
    ANT.addEventListener("click", verANT);
    //funcion que maneja el cambio de imagenes 
    //cuando el usuario da clic en el icono siguiente
    function verANT(){
        var aux= document.getElementById("producto10")
        var ruta=aux.src;
        if(ruta.includes('andrea/b.1.jpg'))
        aux.src="andrea/b.2.jpg";
        else if(ruta.includes('andrea/b.2.jpg'))
        aux.src="andrea/b.3.jpg";
        else if(ruta.includes('andrea/b.3.jpg'))
        aux.src="andrea/b.1.jpg";
        
    } 
      //Se obtiene el incono atras
    var vista_SAT = document.getElementById("SAT");
    //Se registra el evento 
    vista_SAT.addEventListener("click", verSAT);
    //Función que maneja el cambio de imágenes
    //cuando el usuario da clic en el icono atras
    function verSAT(){
        var aux= document.getElementById("producto10")
        var ruta=aux.src;
        if(ruta.includes('andrea/b.1.jpg'))
        aux.src="andrea/b.3.jpg";
        else if(ruta.includes('andrea/b.3.jpg'))
        aux.src="andrea/b.2.jpg";
        else if(ruta.includes('andrea/b.2.jpg'))
        aux.src="andrea/b.1.jpg";
    }
    //Se obtiene el elemento h5 Ver Especificaciones
    var btn= document.getElementById("ver");
    btn.addEventListener("click",mostrarEspecificaciones)
    //Funciín que crea y añade elementos html al DOM
    function mostrarEspecificaciones()
    {
        var text= document.getElementById("spe");
        text.innerHTML="° 100% algondón <br> °manga larga";
        var instrucciones=document.createElement("h5");
        instrucciones.innerHTML="Instrucciones de lavado";
        text.appendChild(instrucciones);
        var andrea_instruciones=document.createElement("andrea")
        andrea_instruciones.src="andrea/cuidados.jpg"
        instrucciones.appendChild(andrea_instruciones);
    }
    //Se obtiene el elemento h5 Ocultr Especificaciones
     var text= document.getElementById("spea");
    var btn2= document.getElementById("ocultar");
    btn2.addEventListener("click",ocultarEspecificaciones)
    //Función elimina las especificaciones
    function ocultarEspecificaciones()
    {
        var elemento= document.getElementById("datos");
        while(elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
        }
        
    }
    {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("BL").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("GR").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("MAR").addEventListener("click", function(){ cambiarImagen(this); } );
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto10");
        switch (objeto.id) {
             case 'BL':
                aux.src="andrea/b.1.jpg"
                break;
            case 'GR':
                aux.src="andrea/n3.jpg"
                break;
                case 'MAR':
                aux.src="andrea/A4.jpg"
                break;
                
        }
    }
        
    }
        
  /*-------------------------------------------OVEROLES----------------------------------------------*/
  
     {
        var elemento= document.getElementById("datos");
        while (elemento.firstChild){
            elemento.removeChild(elemento.firstChild);
    }
      //Obtiene y registra cada evento que cambia la foto al dar clic en los iconos de círculo
    document.getElementById("mez").addEventListener("click", function(){ cambiarImagen(this); } );
    
    document.getElementById("MEZ").addEventListener("click", function(){ cambiarImagen(this); } );
    
    //Función que controla el cambio de imagenes del reloj Garmin
    function cambiarImagen(objeto)
    {
        var aux = document.getElementById("producto 10");
        switch (objeto.id) {
            case 'mez':
                aux.src="andrea/O3.jpg"
                break;
                case 'MEZ':
                aux.src="andrea/O1.jpg"
                break;
        }
    }
       
    } 

    }/*FIN DE TODA LA ESTRUCTURA*/
    

        